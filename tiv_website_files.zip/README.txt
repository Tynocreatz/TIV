TIV Digital Studios Website

Files included:
- index.html (main website)
- Place your logo named 'logo.png' in this folder
- Add videos named video1.mp4, video2.mp4, video3.mp4

Open index.html in a browser to preview the site.
Upload all files to GitHub to publish.